﻿using Franz.Common.Mediator.Messages;
using System;
using System.Collections.Generic;
using System.Text;

namespace HeroService.Contracts.Commands.Heroes.Classifications.OriginArchetype;


public sealed record RetireOriginArchetypeCommand(Guid Id) : ICommand;
