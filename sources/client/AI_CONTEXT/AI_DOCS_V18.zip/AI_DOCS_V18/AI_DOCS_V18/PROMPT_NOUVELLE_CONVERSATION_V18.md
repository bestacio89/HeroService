# PROMPT D'ENTRÉE — Nouvelle conversation V18

Lis en priorité :
- `Docs/PROJECT_CONTEXT_V18.md`
- `Docs/HANDOFF_PROMPT_V18.md`
- `Docs/ROADMAP_STATUS_V18.md`
- `Docs/COMPONENT_CONNECTIONS_V18.md`
- `AI_DOCS_V18/AI_BOOT_PROMPT_V18.md`
- `AI_DOCS_V18/AI_CONTEXT_V18_STUDIO.md`
- `AI_DOCS_V18/AI_PROJECT_MAP_V18.md`
- `Next_Step_FINAL_V1_updated_V18.txt`

## État de départ à considérer comme vrai
- le runtime 5v5 local est stable
- la minimap V1.1 est déjà terminée
- le flow Hero Selection MVP est déjà implémenté
- `HeroSelectionSessionService` est la vérité du pré-match
- `MatchBootstrapper` construit et applique le `MatchLaunchContext`
- `HeroSpawner` reste central et applique le héros confirmé au runtime local
- la transition pré-match → runtime est déjà implémentée
- le start flow runtime `PreGame -> Countdown -> InGame` est déjà implémenté
- le countdown UI est affiché dans le HUD (CountdownUIPresenter, centré à l'écran)
- l'input gameplay est verrouillé avant `GO`
- le HUD gameplay local est implémenté (HP, mana, niveau, cooldowns)
- la prochaine étape logique recommandée est `STEP 7` — vraie condition de victoire
