# Changelog V18

## Objet
V18 ajoute le Countdown UI et le Gameplay HUD complet pour le héros local.

## Résumé des évolutions depuis V17

### STEP 5.10.D — Countdown UI
- ajout de `CountdownUIPresenter` dans `Assets/Scripts/UI/Runtime/`
- `CountdownUI` GameObject créé directement sous Canvas (pas dans CombatUI) — ancré center/middle
- `CountdownText` enfant TMP_Text, Font Size 130, centré
- le presenter s'abonne aux events de `CountdownController` : `OnCountdownTick` et `OnCountdownCompleted`
- masquage automatique après GO via `HideAfterDelay(1.2f)`
- masquage de sécurité dans `MatchStartFlowController.TryEnterInGame()`
- `MatchStartFlowController` orchestre le presenter : `Show()` avant le countdown, `Hide()` en sécurité
- correction : appel redondant `SubscribeToCountdown()` dans `TryStartCountdown()` retiré — l'abonnement est garanti depuis `Awake()`
- correction : guard `if (gameObject.activeInHierarchy)` avant `StartCoroutine(HideAfterDelay)` dans `HandleCountdownCompleted()`

### STEP 6 — Gameplay HUD
- ajout de `LocalHeroHUDPresenter` dans `Assets/Scripts/UI/Runtime/`
- `LocalHeroHUD` GameObject créé dans `CombatUI`, ancré bottom/center (Pos X=0, Pos Y=80, Width=400, Height=120)
- `HPBar` (gris foncé) + `HPFill` (rouge, Horizontal) + `HPText` (TMP, taille 14)
- `ManaBar` (gris foncé) + `ManaFill` (bleu, Horizontal) + `ManaText` (TMP, taille 14)
- `LevelText` (TMP, taille 20, gras)
- `CooldownOverlay` (Image Radial360, UISprite, Fill Amount=0, Raycast Target décoché) sur `SkillOneButton`, `SkillTwoButton`, `UltimateButton`
- `CooldownText` (TMP, taille 28, gras, LiberationSans SDF - Outline, Raycast Target décoché) sur `SkillOneButton`, `SkillTwoButton`, `UltimateButton`
- `AttackButton` sans overlay ni timer — décision de design validée (CD trop court, non pertinent)
- résolution du héros local via `GameManager.OnMatchStarted` — jamais `FindGameObjectWithTag`
- résolution des skill slots par `transform.Find(name)` — ordre garanti contrairement à `GetComponents`
- timers numériques : entiers uniquement (style Mobile Legends)
- `HeroWorldUI` (world space) et HUD screen space coexistent

## Conséquences produit / architecture
- le match entry flow est maintenant complet de bout en bout avec feedback visuel
- le HUD local donne au joueur toutes les informations de gameplay essentielles
- l'UI reste passive — aucune logique gameplay dans les presenters

## État final V18
Validé en Play Mode :
1. `ModeSelectionPanel`
2. `HeroSelectionPanel`
3. sélection du héros
4. `Confirm`
5. bootstrap runtime appliqué
6. fermeture du pré-match
7. affichage du HUD runtime
8. `PreGame`
9. countdown `3, 2, 1, GO` affiché centré à l'écran
10. entrée en `InGame`
11. input gameplay seulement après `GO`
12. HUD local actif : HP, mana, niveau, cooldowns avec overlay + timer

## Prochaine étape recommandée après V18
- `STEP 7` — vraie condition de victoire (Wonder / Core / objectif principal destructible)
- `STEP 8` — écran de fin de match enrichi
