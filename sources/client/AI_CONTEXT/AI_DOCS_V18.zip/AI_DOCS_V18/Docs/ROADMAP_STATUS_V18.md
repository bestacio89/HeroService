# Roadmap Status V18

## Vision produit
Construire une fondation Unity robuste pour un MOBA 5v5 pensé réseau dès le départ, tout en validant les systèmes gameplay par couches successives.

## Phase 1 — Unity Core
### 1.1 Spawn système 10 héros
Statut : terminé.

### 1.2 Player local parmi les 10
Statut : terminé.

### 1.3 IA basique sur les 9 autres héros
Statut : première version fonctionnelle terminée.

### 1.4 Hero Selection Screen
Statut : **clôturée côté MVP runtime-connectée et start flow complet**.

Validé jusqu'en V18 :
- `ModeSelectionPresenter`
- `HeroSelectionItemView`
- `HeroSelectionPanelPresenter`
- `HeroSelectionSessionService`
- `MatchBootstrapper`
- bouton `Confirm`
- verrouillage après confirmation
- `BuildMatchLaunchContext()`
- application du contexte au runtime via `HeroSpawner.TryApplyLaunchContext(...)`
- transition UX vers le runtime
- phase `PreGame`
- countdown runtime
- countdown UI affiché (CountdownUIPresenter)
- input lock jusqu'à `GO`
- HUD gameplay local (HP, mana, niveau, cooldowns)

Reste à faire pour clôture plus complète :
- extension future lane / owned heroes / data source réelle
- éventuel passage vers une scène match dédiée si le projet l'exige plus tard

### 1.5 GameManager
Statut : terminé sur le socle actuel, avec start flow runtime désormais découplé du bootstrap.

### 1.6 Minimap basique
Statut : terminée en V1.1 validée.

### 1.7 Mort et Respawn des héros / NPC
Statut : terminé en prototype pour les NPC ; base joueur locale en place.

### 1.8 Gameplay HUD
Statut : **terminé en V1 validée (V18)**.
- HP, mana, niveau, cooldowns (overlay radial + timer numérique)
- HeroWorldUI (world space) + LocalHeroHUDPresenter (screen space) coexistent

## Phase 2 — Assets visuels
Statut : non commencé au sens production.

## Phase 3 — Réseau
Statut : non commencé.

## Priorité immédiate recommandée après V18
1. `STEP 7` — vraie condition de victoire Wonder / Core / objectif principal destructible
2. `STEP 8` — écran de fin de partie enrichi (Victory / Defeat, stats basiques)
3. écran de fin de partie enrichi
4. itérations Hero Selection : lane réelle, disponibilité réelle, data source non statique, polish

## Chantier de design futur documenté
### Idée de map innovante
Statut : piste documentée, non prioritaire court terme.

Axes possibles à explorer plus tard :
- map dynamique
- événements de map
- factions
- asymétrie contrôlée
- identité forte du projet

Important :
Cette piste ne doit pas détourner les priorités court terme du socle gameplay et du flow pré-match/runtime.
